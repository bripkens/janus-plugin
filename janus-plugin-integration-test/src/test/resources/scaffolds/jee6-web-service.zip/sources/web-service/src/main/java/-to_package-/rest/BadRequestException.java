package ${project.pckg}.rest;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author Ben Ripkens <bripkens.dev@gmail.com>
 */
public class BadRequestException extends WebApplicationException {

    public BadRequestException(String message) {
        super(Response
                .status(400)
                .entity(message)
                .type(MediaType.TEXT_PLAIN)
                .build());
    }
    
}
