package ${project.pckg};

import org.jasypt.util.password.BasicPasswordEncryptor;

/**
 *
 * @author Ben Ripkens <bripkens.dev@gmail.com>
 */
public class PasswordEncryptor {
    private static final BasicPasswordEncryptor ENCRYPTOR = new BasicPasswordEncryptor();
    
    public static String encrypt(String plainPass) {
        return ENCRYPTOR.encryptPassword(plainPass);
    }
    
    public static boolean checkPassword(String encryptedPass, String plainPasss) {
        return ENCRYPTOR.checkPassword(plainPasss, encryptedPass);
    }
}
