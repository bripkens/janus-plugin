name 'Java EE 6 RESTful web service'
description 'Web based project with RESTeasy web service.'

buildJob {
  name 'deploy-staging'
  no vcs trigger

  tasks {
    shell 'echo "Deploying to staging environment."'
  }
}

buildJob {
  name 'build'

  tasks {
    maven targets: 'clean install', pom: 'pom.xml'
  }

  trigger 'deploy-staging' on success
}