scaffold {
    name 'Java EE 6 RESTful web service'
    description 'Web based project with RESTeasy web service.'
}
